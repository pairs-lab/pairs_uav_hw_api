(cl:in-package pairs_msgs-msg)
(cl:export '(STAMP-VAL
          STAMP
          ACTIVE-VAL
          ACTIVE
          LANDING-VAL
          LANDING
          TAKING_OFF-VAL
          TAKING_OFF
          ELANDING-VAL
          ELANDING
))