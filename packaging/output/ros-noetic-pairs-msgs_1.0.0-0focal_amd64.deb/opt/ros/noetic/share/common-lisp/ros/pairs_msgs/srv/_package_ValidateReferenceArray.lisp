(cl:in-package pairs_msgs-srv)
(cl:export '(ARRAY-VAL
          ARRAY
          SUCCESS-VAL
          SUCCESS
          MESSAGE-VAL
          MESSAGE
))