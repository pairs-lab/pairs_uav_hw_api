(cl:in-package pairs_msgs-srv)
(cl:export '(TO_FRAME_ID-VAL
          TO_FRAME_ID
          ARRAY-VAL
          ARRAY
          SUCCESS-VAL
          SUCCESS
          MESSAGE-VAL
          MESSAGE
          ARRAY-VAL
          ARRAY
))