(cl:in-package pairs_msgs-msg)
(cl:export '(SPAWN_CALLED-VAL
          SPAWN_CALLED
          PROCESSING-VAL
          PROCESSING
          ACTIVE_VEHICLES-VAL
          ACTIVE_VEHICLES
          QUEUED_VEHICLES-VAL
          QUEUED_VEHICLES
          QUEUED_PROCESSES-VAL
          QUEUED_PROCESSES
))