(cl:in-package pairs_msgs-msg)
(cl:export '(ACTIVE-VAL
          ACTIVE
))