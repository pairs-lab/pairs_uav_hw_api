(cl:in-package pairs_msgs-msg)
(cl:export '(FIX_TYPE-VAL
          FIX_TYPE
))