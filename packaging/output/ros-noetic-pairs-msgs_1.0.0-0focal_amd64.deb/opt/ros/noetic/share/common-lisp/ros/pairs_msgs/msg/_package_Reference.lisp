(cl:in-package pairs_msgs-msg)
(cl:export '(POSITION-VAL
          POSITION
          HEADING-VAL
          HEADING
))