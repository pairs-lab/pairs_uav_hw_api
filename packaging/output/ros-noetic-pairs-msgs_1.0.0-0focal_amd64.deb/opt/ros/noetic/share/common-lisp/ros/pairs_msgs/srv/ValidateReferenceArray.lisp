; Auto-generated. Do not edit!


(cl:in-package pairs_msgs-srv)


;//! \htmlinclude ValidateReferenceArray-request.msg.html

(cl:defclass <ValidateReferenceArray-request> (roslisp-msg-protocol:ros-message)
  ((array
    :reader array
    :initarg :array
    :type pairs_msgs-msg:ReferenceArray
    :initform (cl:make-instance 'pairs_msgs-msg:ReferenceArray)))
)

(cl:defclass ValidateReferenceArray-request (<ValidateReferenceArray-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <ValidateReferenceArray-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'ValidateReferenceArray-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pairs_msgs-srv:<ValidateReferenceArray-request> is deprecated: use pairs_msgs-srv:ValidateReferenceArray-request instead.")))

(cl:ensure-generic-function 'array-val :lambda-list '(m))
(cl:defmethod array-val ((m <ValidateReferenceArray-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-srv:array-val is deprecated.  Use pairs_msgs-srv:array instead.")
  (array m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <ValidateReferenceArray-request>) ostream)
  "Serializes a message object of type '<ValidateReferenceArray-request>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'array) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <ValidateReferenceArray-request>) istream)
  "Deserializes a message object of type '<ValidateReferenceArray-request>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'array) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<ValidateReferenceArray-request>)))
  "Returns string type for a service object of type '<ValidateReferenceArray-request>"
  "pairs_msgs/ValidateReferenceArrayRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'ValidateReferenceArray-request)))
  "Returns string type for a service object of type 'ValidateReferenceArray-request"
  "pairs_msgs/ValidateReferenceArrayRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<ValidateReferenceArray-request>)))
  "Returns md5sum for a message object of type '<ValidateReferenceArray-request>"
  "46491d4c7f943df7ad4ac8baeaa1711f")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'ValidateReferenceArray-request)))
  "Returns md5sum for a message object of type 'ValidateReferenceArray-request"
  "46491d4c7f943df7ad4ac8baeaa1711f")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<ValidateReferenceArray-request>)))
  "Returns full string definition for message of type '<ValidateReferenceArray-request>"
  (cl:format cl:nil "pairs_msgs/ReferenceArray array~%~%================================================================================~%MSG: pairs_msgs/ReferenceArray~%# A list of references.~%~%std_msgs/Header header~%pairs_msgs/Reference[] array~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: pairs_msgs/Reference~%# This message defines a control reference with a Position+Heading.~%~%geometry_msgs/Point position~%~%# Heading is atan2() of XY-world projection of the UAV's body X-axis.~%float64 heading~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'ValidateReferenceArray-request)))
  "Returns full string definition for message of type 'ValidateReferenceArray-request"
  (cl:format cl:nil "pairs_msgs/ReferenceArray array~%~%================================================================================~%MSG: pairs_msgs/ReferenceArray~%# A list of references.~%~%std_msgs/Header header~%pairs_msgs/Reference[] array~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: pairs_msgs/Reference~%# This message defines a control reference with a Position+Heading.~%~%geometry_msgs/Point position~%~%# Heading is atan2() of XY-world projection of the UAV's body X-axis.~%float64 heading~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <ValidateReferenceArray-request>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'array))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <ValidateReferenceArray-request>))
  "Converts a ROS message object to a list"
  (cl:list 'ValidateReferenceArray-request
    (cl:cons ':array (array msg))
))
;//! \htmlinclude ValidateReferenceArray-response.msg.html

(cl:defclass <ValidateReferenceArray-response> (roslisp-msg-protocol:ros-message)
  ((success
    :reader success
    :initarg :success
    :type (cl:vector cl:boolean)
   :initform (cl:make-array 0 :element-type 'cl:boolean :initial-element cl:nil))
   (message
    :reader message
    :initarg :message
    :type cl:string
    :initform ""))
)

(cl:defclass ValidateReferenceArray-response (<ValidateReferenceArray-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <ValidateReferenceArray-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'ValidateReferenceArray-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pairs_msgs-srv:<ValidateReferenceArray-response> is deprecated: use pairs_msgs-srv:ValidateReferenceArray-response instead.")))

(cl:ensure-generic-function 'success-val :lambda-list '(m))
(cl:defmethod success-val ((m <ValidateReferenceArray-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-srv:success-val is deprecated.  Use pairs_msgs-srv:success instead.")
  (success m))

(cl:ensure-generic-function 'message-val :lambda-list '(m))
(cl:defmethod message-val ((m <ValidateReferenceArray-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-srv:message-val is deprecated.  Use pairs_msgs-srv:message instead.")
  (message m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <ValidateReferenceArray-response>) ostream)
  "Serializes a message object of type '<ValidateReferenceArray-response>"
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'success))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if ele 1 0)) ostream))
   (cl:slot-value msg 'success))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'message))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'message))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <ValidateReferenceArray-response>) istream)
  "Deserializes a message object of type '<ValidateReferenceArray-response>"
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'success) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'success)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:not (cl:zerop (cl:read-byte istream)))))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'message) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'message) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<ValidateReferenceArray-response>)))
  "Returns string type for a service object of type '<ValidateReferenceArray-response>"
  "pairs_msgs/ValidateReferenceArrayResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'ValidateReferenceArray-response)))
  "Returns string type for a service object of type 'ValidateReferenceArray-response"
  "pairs_msgs/ValidateReferenceArrayResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<ValidateReferenceArray-response>)))
  "Returns md5sum for a message object of type '<ValidateReferenceArray-response>"
  "46491d4c7f943df7ad4ac8baeaa1711f")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'ValidateReferenceArray-response)))
  "Returns md5sum for a message object of type 'ValidateReferenceArray-response"
  "46491d4c7f943df7ad4ac8baeaa1711f")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<ValidateReferenceArray-response>)))
  "Returns full string definition for message of type '<ValidateReferenceArray-response>"
  (cl:format cl:nil "bool[] success~%string message~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'ValidateReferenceArray-response)))
  "Returns full string definition for message of type 'ValidateReferenceArray-response"
  (cl:format cl:nil "bool[] success~%string message~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <ValidateReferenceArray-response>))
  (cl:+ 0
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'success) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 1)))
     4 (cl:length (cl:slot-value msg 'message))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <ValidateReferenceArray-response>))
  "Converts a ROS message object to a list"
  (cl:list 'ValidateReferenceArray-response
    (cl:cons ':success (success msg))
    (cl:cons ':message (message msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'ValidateReferenceArray)))
  'ValidateReferenceArray-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'ValidateReferenceArray)))
  'ValidateReferenceArray-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'ValidateReferenceArray)))
  "Returns string type for a service object of type '<ValidateReferenceArray>"
  "pairs_msgs/ValidateReferenceArray")