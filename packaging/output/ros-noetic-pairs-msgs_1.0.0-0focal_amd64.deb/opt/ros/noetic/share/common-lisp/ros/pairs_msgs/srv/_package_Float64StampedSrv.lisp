(cl:in-package pairs_msgs-srv)
(cl:export '(HEADER-VAL
          HEADER
          VALUE-VAL
          VALUE
          SUCCESS-VAL
          SUCCESS
          MESSAGE-VAL
          MESSAGE
))