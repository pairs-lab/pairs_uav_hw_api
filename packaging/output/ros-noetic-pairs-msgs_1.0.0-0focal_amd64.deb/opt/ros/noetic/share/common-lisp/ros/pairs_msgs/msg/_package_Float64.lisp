(cl:in-package pairs_msgs-msg)
(cl:export '(VALUE-VAL
          VALUE
))