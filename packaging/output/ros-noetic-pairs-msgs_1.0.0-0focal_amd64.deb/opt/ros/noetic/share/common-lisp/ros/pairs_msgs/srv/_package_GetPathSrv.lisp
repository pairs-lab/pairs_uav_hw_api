(cl:in-package pairs_msgs-srv)
(cl:export '(PATH-VAL
          PATH
          SUCCESS-VAL
          SUCCESS
          MESSAGE-VAL
          MESSAGE
          TRAJECTORY-VAL
          TRAJECTORY
          WAYPOINT_TRAJECTORY_IDXS-VAL
          WAYPOINT_TRAJECTORY_IDXS
))