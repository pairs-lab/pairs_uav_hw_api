(cl:in-package pairs_msgs-srv)
(cl:export '(FRAME_ID-VAL
          FRAME_ID
          REFERENCE-VAL
          REFERENCE
          SUCCESS-VAL
          SUCCESS
          MESSAGE-VAL
          MESSAGE
          REFERENCE-VAL
          REFERENCE
))