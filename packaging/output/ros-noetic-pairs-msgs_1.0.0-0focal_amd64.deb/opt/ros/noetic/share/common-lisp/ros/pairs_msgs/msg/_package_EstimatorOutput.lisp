(cl:in-package pairs_msgs-msg)
(cl:export '(HEADER-VAL
          HEADER
          STATE-VAL
          STATE
          COVARIANCE-VAL
          COVARIANCE
))