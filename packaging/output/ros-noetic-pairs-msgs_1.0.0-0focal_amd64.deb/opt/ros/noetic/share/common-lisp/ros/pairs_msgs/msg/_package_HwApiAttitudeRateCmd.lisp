(cl:in-package pairs_msgs-msg)
(cl:export '(STAMP-VAL
          STAMP
          BODY_RATE-VAL
          BODY_RATE
          THROTTLE-VAL
          THROTTLE
))