(cl:in-package pairs_msgs-srv)
(cl:export '(GOAL-VAL
          GOAL
          SUCCESS-VAL
          SUCCESS
          MESSAGE-VAL
          MESSAGE
))