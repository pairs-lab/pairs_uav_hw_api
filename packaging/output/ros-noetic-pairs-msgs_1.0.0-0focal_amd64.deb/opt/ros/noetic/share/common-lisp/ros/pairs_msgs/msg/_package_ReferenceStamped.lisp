(cl:in-package pairs_msgs-msg)
(cl:export '(HEADER-VAL
          HEADER
          REFERENCE-VAL
          REFERENCE
))