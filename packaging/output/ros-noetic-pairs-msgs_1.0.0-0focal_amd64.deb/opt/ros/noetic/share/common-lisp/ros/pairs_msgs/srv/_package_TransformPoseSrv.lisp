(cl:in-package pairs_msgs-srv)
(cl:export '(FRAME_ID-VAL
          FRAME_ID
          POSE-VAL
          POSE
          SUCCESS-VAL
          SUCCESS
          MESSAGE-VAL
          MESSAGE
          POSE-VAL
          POSE
))