(cl:in-package pairs_msgs-msg)
(cl:export '(STAMP-VAL
          STAMP
          CHANNELS-VAL
          CHANNELS
))