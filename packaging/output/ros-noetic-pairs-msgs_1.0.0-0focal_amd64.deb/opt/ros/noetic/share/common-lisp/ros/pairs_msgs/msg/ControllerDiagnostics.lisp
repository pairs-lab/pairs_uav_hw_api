; Auto-generated. Do not edit!


(cl:in-package pairs_msgs-msg)


;//! \htmlinclude ControllerDiagnostics.msg.html

(cl:defclass <ControllerDiagnostics> (roslisp-msg-protocol:ros-message)
  ((stamp
    :reader stamp
    :initarg :stamp
    :type std_msgs-msg:Time
    :initform (cl:make-instance 'std_msgs-msg:Time))
   (controller
    :reader controller
    :initarg :controller
    :type cl:string
    :initform "")
   (ramping_up
    :reader ramping_up
    :initarg :ramping_up
    :type cl:boolean
    :initform cl:nil)
   (mass_estimator
    :reader mass_estimator
    :initarg :mass_estimator
    :type cl:boolean
    :initform cl:nil)
   (mass_difference
    :reader mass_difference
    :initarg :mass_difference
    :type cl:float
    :initform 0.0)
   (total_mass
    :reader total_mass
    :initarg :total_mass
    :type cl:float
    :initform 0.0)
   (disturbance_estimator
    :reader disturbance_estimator
    :initarg :disturbance_estimator
    :type cl:boolean
    :initform cl:nil)
   (disturbance_wx_w
    :reader disturbance_wx_w
    :initarg :disturbance_wx_w
    :type cl:float
    :initform 0.0)
   (disturbance_wy_w
    :reader disturbance_wy_w
    :initarg :disturbance_wy_w
    :type cl:float
    :initform 0.0)
   (disturbance_bx_w
    :reader disturbance_bx_w
    :initarg :disturbance_bx_w
    :type cl:float
    :initform 0.0)
   (disturbance_by_w
    :reader disturbance_by_w
    :initarg :disturbance_by_w
    :type cl:float
    :initform 0.0)
   (disturbance_bx_b
    :reader disturbance_bx_b
    :initarg :disturbance_bx_b
    :type cl:float
    :initform 0.0)
   (disturbance_by_b
    :reader disturbance_by_b
    :initarg :disturbance_by_b
    :type cl:float
    :initform 0.0)
   (controller_enforcing_constraints
    :reader controller_enforcing_constraints
    :initarg :controller_enforcing_constraints
    :type cl:boolean
    :initform cl:nil)
   (horizontal_speed_constraint
    :reader horizontal_speed_constraint
    :initarg :horizontal_speed_constraint
    :type cl:float
    :initform 0.0)
   (horizontal_acc_constraint
    :reader horizontal_acc_constraint
    :initarg :horizontal_acc_constraint
    :type cl:float
    :initform 0.0)
   (vertical_asc_speed_constraint
    :reader vertical_asc_speed_constraint
    :initarg :vertical_asc_speed_constraint
    :type cl:float
    :initform 0.0)
   (vertical_asc_acc_constraint
    :reader vertical_asc_acc_constraint
    :initarg :vertical_asc_acc_constraint
    :type cl:float
    :initform 0.0)
   (vertical_desc_speed_constraint
    :reader vertical_desc_speed_constraint
    :initarg :vertical_desc_speed_constraint
    :type cl:float
    :initform 0.0)
   (vertical_desc_acc_constraint
    :reader vertical_desc_acc_constraint
    :initarg :vertical_desc_acc_constraint
    :type cl:float
    :initform 0.0))
)

(cl:defclass ControllerDiagnostics (<ControllerDiagnostics>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <ControllerDiagnostics>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'ControllerDiagnostics)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pairs_msgs-msg:<ControllerDiagnostics> is deprecated: use pairs_msgs-msg:ControllerDiagnostics instead.")))

(cl:ensure-generic-function 'stamp-val :lambda-list '(m))
(cl:defmethod stamp-val ((m <ControllerDiagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-msg:stamp-val is deprecated.  Use pairs_msgs-msg:stamp instead.")
  (stamp m))

(cl:ensure-generic-function 'controller-val :lambda-list '(m))
(cl:defmethod controller-val ((m <ControllerDiagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-msg:controller-val is deprecated.  Use pairs_msgs-msg:controller instead.")
  (controller m))

(cl:ensure-generic-function 'ramping_up-val :lambda-list '(m))
(cl:defmethod ramping_up-val ((m <ControllerDiagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-msg:ramping_up-val is deprecated.  Use pairs_msgs-msg:ramping_up instead.")
  (ramping_up m))

(cl:ensure-generic-function 'mass_estimator-val :lambda-list '(m))
(cl:defmethod mass_estimator-val ((m <ControllerDiagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-msg:mass_estimator-val is deprecated.  Use pairs_msgs-msg:mass_estimator instead.")
  (mass_estimator m))

(cl:ensure-generic-function 'mass_difference-val :lambda-list '(m))
(cl:defmethod mass_difference-val ((m <ControllerDiagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-msg:mass_difference-val is deprecated.  Use pairs_msgs-msg:mass_difference instead.")
  (mass_difference m))

(cl:ensure-generic-function 'total_mass-val :lambda-list '(m))
(cl:defmethod total_mass-val ((m <ControllerDiagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-msg:total_mass-val is deprecated.  Use pairs_msgs-msg:total_mass instead.")
  (total_mass m))

(cl:ensure-generic-function 'disturbance_estimator-val :lambda-list '(m))
(cl:defmethod disturbance_estimator-val ((m <ControllerDiagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-msg:disturbance_estimator-val is deprecated.  Use pairs_msgs-msg:disturbance_estimator instead.")
  (disturbance_estimator m))

(cl:ensure-generic-function 'disturbance_wx_w-val :lambda-list '(m))
(cl:defmethod disturbance_wx_w-val ((m <ControllerDiagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-msg:disturbance_wx_w-val is deprecated.  Use pairs_msgs-msg:disturbance_wx_w instead.")
  (disturbance_wx_w m))

(cl:ensure-generic-function 'disturbance_wy_w-val :lambda-list '(m))
(cl:defmethod disturbance_wy_w-val ((m <ControllerDiagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-msg:disturbance_wy_w-val is deprecated.  Use pairs_msgs-msg:disturbance_wy_w instead.")
  (disturbance_wy_w m))

(cl:ensure-generic-function 'disturbance_bx_w-val :lambda-list '(m))
(cl:defmethod disturbance_bx_w-val ((m <ControllerDiagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-msg:disturbance_bx_w-val is deprecated.  Use pairs_msgs-msg:disturbance_bx_w instead.")
  (disturbance_bx_w m))

(cl:ensure-generic-function 'disturbance_by_w-val :lambda-list '(m))
(cl:defmethod disturbance_by_w-val ((m <ControllerDiagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-msg:disturbance_by_w-val is deprecated.  Use pairs_msgs-msg:disturbance_by_w instead.")
  (disturbance_by_w m))

(cl:ensure-generic-function 'disturbance_bx_b-val :lambda-list '(m))
(cl:defmethod disturbance_bx_b-val ((m <ControllerDiagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-msg:disturbance_bx_b-val is deprecated.  Use pairs_msgs-msg:disturbance_bx_b instead.")
  (disturbance_bx_b m))

(cl:ensure-generic-function 'disturbance_by_b-val :lambda-list '(m))
(cl:defmethod disturbance_by_b-val ((m <ControllerDiagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-msg:disturbance_by_b-val is deprecated.  Use pairs_msgs-msg:disturbance_by_b instead.")
  (disturbance_by_b m))

(cl:ensure-generic-function 'controller_enforcing_constraints-val :lambda-list '(m))
(cl:defmethod controller_enforcing_constraints-val ((m <ControllerDiagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-msg:controller_enforcing_constraints-val is deprecated.  Use pairs_msgs-msg:controller_enforcing_constraints instead.")
  (controller_enforcing_constraints m))

(cl:ensure-generic-function 'horizontal_speed_constraint-val :lambda-list '(m))
(cl:defmethod horizontal_speed_constraint-val ((m <ControllerDiagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-msg:horizontal_speed_constraint-val is deprecated.  Use pairs_msgs-msg:horizontal_speed_constraint instead.")
  (horizontal_speed_constraint m))

(cl:ensure-generic-function 'horizontal_acc_constraint-val :lambda-list '(m))
(cl:defmethod horizontal_acc_constraint-val ((m <ControllerDiagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-msg:horizontal_acc_constraint-val is deprecated.  Use pairs_msgs-msg:horizontal_acc_constraint instead.")
  (horizontal_acc_constraint m))

(cl:ensure-generic-function 'vertical_asc_speed_constraint-val :lambda-list '(m))
(cl:defmethod vertical_asc_speed_constraint-val ((m <ControllerDiagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-msg:vertical_asc_speed_constraint-val is deprecated.  Use pairs_msgs-msg:vertical_asc_speed_constraint instead.")
  (vertical_asc_speed_constraint m))

(cl:ensure-generic-function 'vertical_asc_acc_constraint-val :lambda-list '(m))
(cl:defmethod vertical_asc_acc_constraint-val ((m <ControllerDiagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-msg:vertical_asc_acc_constraint-val is deprecated.  Use pairs_msgs-msg:vertical_asc_acc_constraint instead.")
  (vertical_asc_acc_constraint m))

(cl:ensure-generic-function 'vertical_desc_speed_constraint-val :lambda-list '(m))
(cl:defmethod vertical_desc_speed_constraint-val ((m <ControllerDiagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-msg:vertical_desc_speed_constraint-val is deprecated.  Use pairs_msgs-msg:vertical_desc_speed_constraint instead.")
  (vertical_desc_speed_constraint m))

(cl:ensure-generic-function 'vertical_desc_acc_constraint-val :lambda-list '(m))
(cl:defmethod vertical_desc_acc_constraint-val ((m <ControllerDiagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-msg:vertical_desc_acc_constraint-val is deprecated.  Use pairs_msgs-msg:vertical_desc_acc_constraint instead.")
  (vertical_desc_acc_constraint m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <ControllerDiagnostics>) ostream)
  "Serializes a message object of type '<ControllerDiagnostics>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'stamp) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'controller))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'controller))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'ramping_up) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'mass_estimator) 1 0)) ostream)
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'mass_difference))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'total_mass))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'disturbance_estimator) 1 0)) ostream)
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'disturbance_wx_w))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'disturbance_wy_w))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'disturbance_bx_w))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'disturbance_by_w))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'disturbance_bx_b))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'disturbance_by_b))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'controller_enforcing_constraints) 1 0)) ostream)
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'horizontal_speed_constraint))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'horizontal_acc_constraint))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'vertical_asc_speed_constraint))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'vertical_asc_acc_constraint))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'vertical_desc_speed_constraint))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'vertical_desc_acc_constraint))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <ControllerDiagnostics>) istream)
  "Deserializes a message object of type '<ControllerDiagnostics>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'stamp) istream)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'controller) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'controller) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:slot-value msg 'ramping_up) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'mass_estimator) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'mass_difference) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'total_mass) (roslisp-utils:decode-double-float-bits bits)))
    (cl:setf (cl:slot-value msg 'disturbance_estimator) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'disturbance_wx_w) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'disturbance_wy_w) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'disturbance_bx_w) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'disturbance_by_w) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'disturbance_bx_b) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'disturbance_by_b) (roslisp-utils:decode-double-float-bits bits)))
    (cl:setf (cl:slot-value msg 'controller_enforcing_constraints) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'horizontal_speed_constraint) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'horizontal_acc_constraint) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'vertical_asc_speed_constraint) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'vertical_asc_acc_constraint) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'vertical_desc_speed_constraint) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'vertical_desc_acc_constraint) (roslisp-utils:decode-double-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<ControllerDiagnostics>)))
  "Returns string type for a message object of type '<ControllerDiagnostics>"
  "pairs_msgs/ControllerDiagnostics")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'ControllerDiagnostics)))
  "Returns string type for a message object of type 'ControllerDiagnostics"
  "pairs_msgs/ControllerDiagnostics")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<ControllerDiagnostics>)))
  "Returns md5sum for a message object of type '<ControllerDiagnostics>"
  "e33bff357ddf307f9583c2ff3c901553")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'ControllerDiagnostics)))
  "Returns md5sum for a message object of type 'ControllerDiagnostics"
  "e33bff357ddf307f9583c2ff3c901553")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<ControllerDiagnostics>)))
  "Returns full string definition for message of type '<ControllerDiagnostics>"
  (cl:format cl:nil "std_msgs/Time stamp~%~%# The name of the controller (implementation-wise).~%# Beware, multiple instances of the same controller can be running.~%# The ControlManagerDiagnostics message contains the name given them~%# by the ControlManager.~%string controller~%~%# True if the controller is in the initial rampup phase (just after activation).~%bool ramping_up~%~%# true if the mass estimator is running~%bool mass_estimator~%~%# The estimated mass difference from the nominal mass.~%float64 mass_difference~%~%# Total estimated UAV mass.~%float64 total_mass~%~%# true if disturbance estimators are running~%bool disturbance_estimator~%~%# World-frame disturbances expressed in the world frame.~%float64 disturbance_wx_w~%float64 disturbance_wy_w~%~%# Body-frame (fcu_untilted) disturbances expressed in the world frame.~%float64 disturbance_bx_w~%float64 disturbance_by_w~%~%# Body-frame (fcu_untilted) disturbances expressed in the body frame (fcu_untilted).~%float64 disturbance_bx_b~%float64 disturbance_by_b~%~%# The controller can enforce dynamics constraints over the trackers.~%# This can be used when flying with a controller that is limited to~%# some maximum speed and acceleration.~%bool controller_enforcing_constraints~%float64 horizontal_speed_constraint~%float64 horizontal_acc_constraint~%float64 vertical_asc_speed_constraint~%float64 vertical_asc_acc_constraint~%float64 vertical_desc_speed_constraint~%float64 vertical_desc_acc_constraint~%~%================================================================================~%MSG: std_msgs/Time~%time data~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'ControllerDiagnostics)))
  "Returns full string definition for message of type 'ControllerDiagnostics"
  (cl:format cl:nil "std_msgs/Time stamp~%~%# The name of the controller (implementation-wise).~%# Beware, multiple instances of the same controller can be running.~%# The ControlManagerDiagnostics message contains the name given them~%# by the ControlManager.~%string controller~%~%# True if the controller is in the initial rampup phase (just after activation).~%bool ramping_up~%~%# true if the mass estimator is running~%bool mass_estimator~%~%# The estimated mass difference from the nominal mass.~%float64 mass_difference~%~%# Total estimated UAV mass.~%float64 total_mass~%~%# true if disturbance estimators are running~%bool disturbance_estimator~%~%# World-frame disturbances expressed in the world frame.~%float64 disturbance_wx_w~%float64 disturbance_wy_w~%~%# Body-frame (fcu_untilted) disturbances expressed in the world frame.~%float64 disturbance_bx_w~%float64 disturbance_by_w~%~%# Body-frame (fcu_untilted) disturbances expressed in the body frame (fcu_untilted).~%float64 disturbance_bx_b~%float64 disturbance_by_b~%~%# The controller can enforce dynamics constraints over the trackers.~%# This can be used when flying with a controller that is limited to~%# some maximum speed and acceleration.~%bool controller_enforcing_constraints~%float64 horizontal_speed_constraint~%float64 horizontal_acc_constraint~%float64 vertical_asc_speed_constraint~%float64 vertical_asc_acc_constraint~%float64 vertical_desc_speed_constraint~%float64 vertical_desc_acc_constraint~%~%================================================================================~%MSG: std_msgs/Time~%time data~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <ControllerDiagnostics>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'stamp))
     4 (cl:length (cl:slot-value msg 'controller))
     1
     1
     8
     8
     1
     8
     8
     8
     8
     8
     8
     1
     8
     8
     8
     8
     8
     8
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <ControllerDiagnostics>))
  "Converts a ROS message object to a list"
  (cl:list 'ControllerDiagnostics
    (cl:cons ':stamp (stamp msg))
    (cl:cons ':controller (controller msg))
    (cl:cons ':ramping_up (ramping_up msg))
    (cl:cons ':mass_estimator (mass_estimator msg))
    (cl:cons ':mass_difference (mass_difference msg))
    (cl:cons ':total_mass (total_mass msg))
    (cl:cons ':disturbance_estimator (disturbance_estimator msg))
    (cl:cons ':disturbance_wx_w (disturbance_wx_w msg))
    (cl:cons ':disturbance_wy_w (disturbance_wy_w msg))
    (cl:cons ':disturbance_bx_w (disturbance_bx_w msg))
    (cl:cons ':disturbance_by_w (disturbance_by_w msg))
    (cl:cons ':disturbance_bx_b (disturbance_bx_b msg))
    (cl:cons ':disturbance_by_b (disturbance_by_b msg))
    (cl:cons ':controller_enforcing_constraints (controller_enforcing_constraints msg))
    (cl:cons ':horizontal_speed_constraint (horizontal_speed_constraint msg))
    (cl:cons ':horizontal_acc_constraint (horizontal_acc_constraint msg))
    (cl:cons ':vertical_asc_speed_constraint (vertical_asc_speed_constraint msg))
    (cl:cons ':vertical_asc_acc_constraint (vertical_asc_acc_constraint msg))
    (cl:cons ':vertical_desc_speed_constraint (vertical_desc_speed_constraint msg))
    (cl:cons ':vertical_desc_acc_constraint (vertical_desc_acc_constraint msg))
))
