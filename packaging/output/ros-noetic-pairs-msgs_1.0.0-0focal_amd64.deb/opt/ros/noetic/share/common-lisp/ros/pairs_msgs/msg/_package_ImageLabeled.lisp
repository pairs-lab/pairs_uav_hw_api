(cl:in-package pairs_msgs-msg)
(cl:export '(LABEL-VAL
          LABEL
          IMG-VAL
          IMG
))