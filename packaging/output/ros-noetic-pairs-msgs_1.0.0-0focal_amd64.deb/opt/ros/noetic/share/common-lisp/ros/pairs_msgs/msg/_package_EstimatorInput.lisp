(cl:in-package pairs_msgs-msg)
(cl:export '(HEADER-VAL
          HEADER
          CONTROL_ACCELERATION-VAL
          CONTROL_ACCELERATION
          CONTROL_HDG_RATE-VAL
          CONTROL_HDG_RATE
))