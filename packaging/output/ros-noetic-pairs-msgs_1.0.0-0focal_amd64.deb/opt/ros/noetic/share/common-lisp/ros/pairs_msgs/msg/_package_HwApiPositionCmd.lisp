(cl:in-package pairs_msgs-msg)
(cl:export '(HEADER-VAL
          HEADER
          POSITION-VAL
          POSITION
          HEADING-VAL
          HEADING
))