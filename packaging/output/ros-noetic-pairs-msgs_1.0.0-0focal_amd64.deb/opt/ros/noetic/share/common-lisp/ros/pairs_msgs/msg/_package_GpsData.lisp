(cl:in-package pairs_msgs-msg)
(cl:export '(LATITUDE-VAL
          LATITUDE
          LONGITUDE-VAL
          LONGITUDE
          ALTITUDE-VAL
          ALTITUDE
          COVARIANCE-VAL
          COVARIANCE
))