(cl:in-package pairs_msgs-srv)
(cl:export '(VALUE-VAL
          VALUE
          SUCCESS-VAL
          SUCCESS
))